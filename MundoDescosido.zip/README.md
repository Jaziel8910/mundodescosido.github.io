# Mundo Descosido - Edición Definitiva

Este es el repositorio del juego "Mundo Descosido", un juego de parkour procedural en 3D.

## Estructura del Repositorio

- **/game/**: Contiene la versión compilada y jugable del juego. Para jugar, sigue las instrucciones en `game/INSTRUCTIONS.md`.
- **/source_code/**: Contiene todo el código fuente, las dependencias y los archivos de configuración del proyecto.

## Créditos

- **Desarrollado por:** Jaziel
- **Asistente de IA:** Jules
